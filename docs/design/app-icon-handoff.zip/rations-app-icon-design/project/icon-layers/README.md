# Rations — Icon Composer layers

All files are 1024 × 1024 SVG on the Icon Composer canvas. Build the icon from three layers, bottom to top:

1. **Background** — set Icon Composer's background fill to a top → bottom gradient (values below). `background-*.svg` carries the same gradient if you prefer it as a layer.
2. **glow.svg** — Fill: glow color · Opacity ≈ 45 % · Blur ≈ 60 · Specular off · Shadow off.
3. **glyph-band.svg** (menu-bar outline) or **glyph-disc.svg** (solid) — Fill: glyph color · Specular on · Shadow: neutral · Translucency ≈ 30 % · Blur off.

Palettes
- graphite: background #4B5058 → #14161A · glow #A3ABB8 · glyph #FFFFFF
- olive: background #78873F → #262F16 · glow #D3D195 · glyph #FBF8EA
- amber: background #FFBE4A → #B9540C · glow #FFE6A6 · glyph #FFFFFF
- blue: background #58A9FF → #0A4FC4 · glow #BFE0FF · glyph #FFFFFF

Geometry: NATO APP-6A food-and-rations glyph as in `StatusGlyph.swift` — 270° arc, 90° opening facing right, 68 px band on a 330 px outer radius. Centers are shifted right (546 for the band, 566 for the disc) so the glyph reads centered despite the opening.

Attribution: adapted from CdnMCG, CC BY-SA 4.0 — see `apps/macos/Resources/IconAttribution.txt`.
