repo: rawcontext/rations
branch: master

## Last sync
date: 2026-09-15T06:13:32Z

### Updated in this project
- App icon explorations (1a–1h) built from the StatusGlyph.swift geometry: NATO APP-6A food-and-rations glyph, 270° arc, right-facing 90° opening
- Icon Composer layer SVGs and assembly notes in icon-layers/

## Screen map
| Screen | Repo files |
|---|---|
| Rations App Icon.dc.html (turn 1, options 1a–1h) | apps/macos/Sources/Menu/StatusGlyph.swift, apps/macos/Resources/IconAttribution.txt, docs/design/README.md, docs/design/references/static-menu-icon.png |
| icon-layers/*.svg, icon-layers/README.md | apps/macos/Sources/Menu/StatusGlyph.swift |
